import java.util.Scanner;

public class AppEnergia {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese la ubicacion de la instalacion:");
        String ubicacion = sc.nextLine();
        System.out.println("Ingrese la eficiencia (entre 0 y 10):");
        String eficiencia = sc.nextLine();
        System.out.println("Ingrese el area:");
        String area = sc.nextLine();
        System.out.println("Ingrese la fecha:");
        String fecha = sc.nextLine();
        System.out.println("Ingrese el estado:");
        String estado = sc.nextLine();

        Instalacion inst = new Instalacion (ubicacion, eficiencia, area, fecha, estado);


        //datos responsable
        System.out.println(" Ingrese nombre responsable: ");
        String nombre = sc.nextLine();
        System.out.println(" Ingrese documento del responsable: ");
        String documento = sc.nextLine();
        System.out.println(" Ingrese telefono del responsable: ");
        String telefono = sc.nextLine();
        System.out.println(" Ingrese ciudad del responsable: ");
        String ciudad = sc.nextLine();
        System.out.println("ingrese la institucion del responsable:");
        String institucion = sc.nextLine();

        Responsable res = new Responsable(nombre, documento, telefono, ciudad, institucion);

        System.out.println("\nLos datos de la instalación son: ");
        inst.MostrarDatos();

        System.out.println("\nLos datos del responsable son: ");
        res.MostrarDatos();
        System.out.println("Institución: " + ((Responsable)res).getInstitucion());

        System.out.println("----------------------------------");

        System.out.println("Desea actualizar la eficiencia? (si / no): ");
        String a = sc.nextLine();

        if (a.equals("no")) {
            System.exit(0);
        }else {
            System.out.println("Actulizar eficiencia Instalación: ");
            String nuevaEficiencia = sc.nextLine();

            inst.setEficiencia(nuevaEficiencia);
            System.out.println("\nEficiencia Actualizada: ");
            inst.MostrarDatos();
        }


    }
}
