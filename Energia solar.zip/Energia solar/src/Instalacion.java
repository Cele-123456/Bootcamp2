public class Instalacion {
    private String ubicacion;
    private String eficiencia;
    private String area;
    private String fecha;
    private String estado;

    public Instalacion(String ubicacion, String eficiencia, String area, String fecha, String estado) {
        this.ubicacion = ubicacion;
        this.eficiencia = eficiencia;
        this.area = area;
        this.fecha = fecha;
        this.estado = estado;
    }

    public void MostrarDatos () {
        System.out.println("Ubicación----: " +ubicacion);
        System.out.println("Eficiencia: " +eficiencia);
        System.out.println("Area: " +area);
        System.out.println("Fecha: " +fecha);
        System.out.println("Estado: " +estado);
    }

    public void setEficiencia(String eficiencia) {
        this.eficiencia = eficiencia;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

}
