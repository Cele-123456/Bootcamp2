public class Persona {
    private String nombre;
    private String documento;
    private String telefono;
    private String ciudad;

    //constructor

    public Persona(String nombre, String documento, String telefono, String ciudad) {
        this.nombre = nombre;
        this.documento = documento;
        this.telefono = telefono;
        this.ciudad = ciudad;

    }
    public void MostrarDatos () {
        System.out.println("Nombre: " +nombre);
        System.out.println("Documento: " +documento);
        System.out.println("Telefono: " +telefono);
        System.out.println("Ciudad: " +ciudad);
    }
    /*public String getNombre() {return nombre;}
    public String getDocumento() {return documento;}
    public String getTelefono() {return telefono;}
    public String getCiudad() {return ciudad;}*/
}
