public class Responsable extends Persona {
    private String institucion;

    //constructor

    public Responsable(String nombre, String documento, String telefono, String ciudad, String institucion)
    {
        super(nombre, documento, telefono, ciudad);
        this.institucion = institucion;
    }
    public String getInstitucion() {return institucion;}


}
