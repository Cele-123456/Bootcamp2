import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Que tipo de persona desea registrar? (1:Emprendedor, 2:Mentor: )");
        int tipo = Integer.parseInt(sc.nextLine());

        System.out.print("Ingrese el Nombre: ");
        String nombre = sc.nextLine();
        System.out.print("Ingrese el Documento: ");
        String documento = sc.nextLine();
        System.out.print("Ingrese la Ciudad: ");
        String ciudad = sc.nextLine();

        if(tipo==1){
            System.out.print("Ingrese el Sector al que pertenece: ");
            String sector = sc.nextLine();
            Emprendedor emprendedor = new Emprendedor(nombre,documento, sector, ciudad);

            System.out.println("\n\nIngrese datos del Proeycto: ");
            System.out.print("\nIngrese el nombre: ");
            String nombreProyecto = sc.nextLine();
            System.out.print("\nIngrese la Descripción");
            String descripcion = sc.next();

            NivelInnovacion nivel = null;
            while(nivel == null){
                try{
                    System.out.println("\nIngrese el nivel de Innovacion (BAJO, MEDIO, ALTO): ");
                    String nivelTexto = sc.nextLine();
                    nivel = NivelInnovacion.valueOf(nivelTexto);
                } catch(IllegalArgumentException e){
                    System.out.println("Error: Nivel no existe, escriba una de las 3 opciones");
                }
            }

            EstadoProyecto estado = null;
            while(estado == null){
                try{
                    System.out.println("\n\nIngrese el estado del proyecto (EN DISEÑO, EN MARCHA, CRECIMIENTO): ");
                    String estadoTexto = sc.nextLine().toUpperCase();
                    estado = EstadoProyecto.valueOf(estadoTexto);
                }catch(IllegalArgumentException e){
                    System.out.println("Valor Estado Invalido, debe escribir alguna de las 3 opciones");
                }
            }

            //Creacion objeto proyecto de tipo Proyecto
            Proyecto proyecto = new Proyecto(nombreProyecto, descripcion, nivel, estado, emprendedor);

            //Mostrar resumen inicial
            System.out.println("\n-------------------------");
            proyecto.mostrarResumen();

        } else if(tipo==2){
            System.out.println("Ingrese el área de experticia: ");
            String area = sc.nextLine();
            Mentor mentor = new Mentor(nombre, documento, ciudad, area);

            System.out.println("---------------------------");
            System.out.println("Mentor Registrado");
            mentor.mostrarDatosBasicos();
        }else {
            System.out.println("Ese tipo de persona no es valido");
        }


        sc.close();

    }
}
