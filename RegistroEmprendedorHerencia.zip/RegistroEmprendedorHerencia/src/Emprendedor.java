//clase hija de persona
public class Emprendedor extends Persona{
    private String sector;

    public Emprendedor(String nombre, String documento, String sector, String ciudad) {
        super(nombre, documento, ciudad);
        this.sector = sector;
    }

    //getter
    public String getSector() {return sector;}

    //muestra datos usando el metodo mostrarDatosBasicos de la clase padre
    // y adicional agregar experticia
    /*@Override
    public void mostrarDatosBasicos(){
        super.mostrarDatosBasicos();
        System.out.println("Sector = "+sector);
    }*/
}