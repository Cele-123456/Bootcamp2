//Clase enum me permite crear constantes simbolicas
public enum EstadoProyecto {
    // Valores predefinidos
    EN_DISENIO,
    EN_MARCHA,
    CRECIMIENTO
}
