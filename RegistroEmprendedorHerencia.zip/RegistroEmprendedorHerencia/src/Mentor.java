//clase hija de Persona
public class Mentor extends Persona {
    private String areaExperticia;

    //constructor
    public Mentor(String nombre, String documento, String areaExperticia, String ciudad) {
        super(nombre, documento, ciudad);
        this.areaExperticia=areaExperticia;
    }

    //getter
    public String getAreaExperticia() {return areaExperticia;}

    //muestra datos usando el metodo mostrarDatosBasicos de la clase padre
    // y adicional agregar experticia
    @Override
    public void mostrarDatosBasicos(){
        super.mostrarDatosBasicos();
        System.out.println("Area Experticia = "+areaExperticia);
    }
}
