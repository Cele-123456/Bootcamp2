//Clase enum me permite crear constantes simbolicas
public enum NivelInnovacion {
    // Valores predefinidos
    BAJO,
    MEDIO,
    ALTO
}
