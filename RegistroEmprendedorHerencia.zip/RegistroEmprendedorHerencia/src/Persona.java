public class Persona {
    // Definir atributos comunes: nombre, documento, ciudad
    //protected tipo nombreAtributo
    protected String nombre;
    protected String documento;
    protected String ciudad;

    //constructor
    public Persona(String nombre, String documento, String ciudad) {
        this.nombre = nombre;
        this.documento = documento;
        this.ciudad = ciudad;
    }

    //getters
    //acceso publico tipo getAtributo() {retorna atributo}
    public String getNombre() { return nombre; }
    public String getDocumento() { return documento; }
    public String getCiudad() { return ciudad; }

    //setter -> acceso publico - no retorna - setAtributo(tipo atributo){
    //  valida que !parametro no está vacio "isEmpty"
    //}
    public void setCiudad(String ciudad) {
        if(!ciudad.isEmpty()) {
            this.ciudad = ciudad;
        }
    }

    //Metodo comun heredable por subclases
    //acceso  publico no retorna nombreMetodo
    //por ejemplo imprime los datos basicos
    public void mostrarDatosBasicos(){
        System.out.println("Nombre: " + nombre);
        System.out.println("Documento: " + documento);
        System.out.println("Ciudad: " + ciudad);
    }
}



