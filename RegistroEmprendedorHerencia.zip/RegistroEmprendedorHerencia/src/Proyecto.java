public class Proyecto {
    private String nombre;
    private String descripcion;
    private NivelInnovacion nivelInnovacion;
    private EstadoProyecto estado;
    private Emprendedor emprendedor;

    //constructor
    public Proyecto(String nombre, String descripcion, NivelInnovacion nivelInnovacion, EstadoProyecto estado, Emprendedor emprendedor) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.nivelInnovacion = nivelInnovacion;
        this.estado = estado;
        this.emprendedor = emprendedor;
    }

    public EstadoProyecto getEstado() { return estado; }

    public void setEstado(EstadoProyecto estado) {
        this.estado = estado;

    }

    public NivelInnovacion getNivelInnovacion() { return nivelInnovacion; }

    public void setNivelInnovacion(NivelInnovacion nivelInnovacion) {
        this.nivelInnovacion = nivelInnovacion;
    }

    public void mostrarResumen() {
        System.out.println("Registro exitoso\n");
        System.out.println(" Emprendedor ");
        /*System.out.println("\tNombre: " + emprendedor.getNombre());
        System.out.println("\tDocumento: " + emprendedor.getDocumento());
        System.out.println("\tSector: " + emprendedor.getSector());
        System.out.println("\tCiudad: " + emprendedor.getCiudad());*/

        if(emprendedor instanceof Emprendedor){
            emprendedor.mostrarDatosBasicos();
            System.out.println("Sector" + ((Emprendedor) emprendedor).getSector());
        }

        System.out.println("\nProyecto");
        System.out.println("\tNombre: " + nombre);
        System.out.println("\tDescripcion: " + descripcion);
        System.out.println("\tNivel de innovacion: " + nivelInnovacion);
        System.out.println("\tEstado: " + estado);
    }
}